package com.quiz.quizeService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quiz.quizeService.entities.quize;

public interface quizRepo  extends JpaRepository<quize,Long>{
    
}
