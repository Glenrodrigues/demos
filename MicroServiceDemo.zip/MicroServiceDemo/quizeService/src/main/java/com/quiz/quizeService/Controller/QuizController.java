package com.quiz.quizeService.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.quizeService.entities.quize;
import com.quiz.quizeService.service.QuestionClient;
import com.quiz.quizeService.service.QuizeService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("/quiz")
public class QuizController {
    
    @Autowired
    private QuizeService quizService;

    @Autowired
    private QuestionClient questionClient;

    public QuizController(QuizeService quizService, QuestionClient questionClient) {
        this.quizService = quizService;
        this.questionClient = questionClient;
    }

    @PostMapping()
    public quize create(@RequestBody quize quiz) {
        return quizService.add(quiz);
    }

    @GetMapping()
    public List<quize> get() {
        return quizService.get();
    }
    
    @GetMapping("/{id}")
    public quize getOne(@PathVariable Long id) {
        return quizService.getOne(id);
    }
    
    
   
}
