package com.question.questionService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.question.questionService.entities.Question;
import java.util.List;


public interface QuestionRepo extends JpaRepository<Question,Long>{


    List<Question> findByQuizeId(Long quizeId);

    
}
